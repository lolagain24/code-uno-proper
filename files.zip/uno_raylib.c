// UNO - Raylib Graphical Version for Windows
// Compile with: gcc uno_raylib.c -o uno.exe -lraylib -lm -lopengl32 -lgdi32 -lwinmm
// Or with raylib installed: gcc uno_raylib.c -o uno -lraylib -lm

#include "raylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// ─── Constants ────────────────────────────────────────────────────────────────
#define MAX_DECK    108
#define MAX_HAND    200
#define MAX_PLAYERS 4

#define SCREEN_W    1280
#define SCREEN_H    720

#define CARD_W      80
#define CARD_H      120
#define CARD_RADIUS 8

// ─── Enums ────────────────────────────────────────────────────────────────────
typedef enum { BLU, GIALLO, ROSSO, VERDE, NERO } CardColor;
typedef enum { NUMERO, SALTA, INVERTI, PIU2, CAMBIO_COLORE, PIU4 } CardType;

// ─── Structs ──────────────────────────────────────────────────────────────────
typedef struct {
    CardColor color;
    CardType  type;
    int       numero;
} Card;

typedef struct {
    Card  cards[MAX_HAND];
    int   count;
    char  nome[32];
    int   isCPU;
} Player;

typedef struct {
    Card cards[MAX_DECK];
    int  top;
    int  size;
} Deck;

// ─── Game state ───────────────────────────────────────────────────────────────
typedef enum {
    SCREEN_MENU,
    SCREEN_SETUP,
    SCREEN_GAME,
    SCREEN_COLOR_PICK,
    SCREEN_WIN
} GameScreen;

typedef struct {
    GameScreen screen;
    int        numPlayers;
    Player     players[MAX_PLAYERS];
    Deck       deck;
    Card       topCard;
    CardColor  currentColor;
    int        currentPlayer;
    int        direction;
    int        skipNext;
    int        drawPenalty;
    int        winner;           // -1 = none
    char       message[256];
    float      messageTimer;
    int        colorPickFor;     // player index waiting for color choice
    int        hoveredCard;      // index of hovered card in human hand
    int        animTimer;        // for CPU "thinking" delay
    int        cpuThinking;      // 1 = CPU is in thinking animation
    float      cpuDelay;
    // Setup screen
    int        setupMode;        // 1 = vs CPU, 2 = multiplayer
    int        setupPlayerCount;
} GameState;

static GameState G;

// ─── Colors ───────────────────────────────────────────────────────────────────
static Color rayColor(CardColor c) {
    switch (c) {
        case BLU:    return (Color){30,  100, 220, 255};
        case GIALLO: return (Color){240, 200,  30, 255};
        case ROSSO:  return (Color){220,  40,  40, 255};
        case VERDE:  return (Color){ 30, 170,  70, 255};
        case NERO:   return (Color){ 20,  20,  20, 255};
        default:     return WHITE;
    }
}

static const char *colorName(CardColor c) {
    switch (c) {
        case BLU:    return "Blue";
        case GIALLO: return "Yellow";
        case ROSSO:  return "Red";
        case VERDE:  return "Green";
        case NERO:   return "Black";
        default:     return "?";
    }
}

static const char *cardLabel(Card c) {
    static char buf[32];
    if (c.type == NUMERO)       { snprintf(buf, sizeof(buf), "%d", c.numero); }
    else if (c.type == SALTA)   { snprintf(buf, sizeof(buf), "SKIP"); }
    else if (c.type == INVERTI) { snprintf(buf, sizeof(buf), "REV"); }
    else if (c.type == PIU2)    { snprintf(buf, sizeof(buf), "+2"); }
    else if (c.type == CAMBIO_COLORE) { snprintf(buf, sizeof(buf), "WILD"); }
    else if (c.type == PIU4)    { snprintf(buf, sizeof(buf), "+4"); }
    return buf;
}

// ─── Deck helpers ─────────────────────────────────────────────────────────────
static void addCardToDeck(Deck *d, CardColor color, CardType type, int numero) {
    d->cards[d->size].color  = color;
    d->cards[d->size].type   = type;
    d->cards[d->size].numero = numero;
    d->size++;
}

static void initDeck(Deck *d) {
    d->size = 0; d->top = 0;
    for (int c = BLU; c <= VERDE; c++) {
        addCardToDeck(d, (CardColor)c, NUMERO, 0);
        for (int n = 1; n <= 9; n++) {
            addCardToDeck(d, (CardColor)c, NUMERO, n);
            addCardToDeck(d, (CardColor)c, NUMERO, n);
        }
        for (int i = 0; i < 2; i++) {
            addCardToDeck(d, (CardColor)c, SALTA,  -1);
            addCardToDeck(d, (CardColor)c, INVERTI,-1);
            addCardToDeck(d, (CardColor)c, PIU2,   -1);
        }
    }
    for (int i = 0; i < 4; i++) {
        addCardToDeck(d, NERO, CAMBIO_COLORE, -1);
        addCardToDeck(d, NERO, PIU4,          -1);
    }
}

static void shuffleDeck(Deck *d) {
    for (int i = d->size - 1; i > 0; i--) {
        int j  = rand() % (i + 1);
        Card t = d->cards[i];
        d->cards[i] = d->cards[j];
        d->cards[j] = t;
    }
}

static int  deckEmpty(Deck *d) { return d->top >= d->size; }
static Card drawCard(Deck *d) {
    Card c = {NERO, CAMBIO_COLORE, -1};
    if (!deckEmpty(d)) c = d->cards[d->top++];
    return c;
}

static void addToHand(Player *p, Card c) {
    if (p->count < MAX_HAND) p->cards[p->count++] = c;
}

static Card removeFromHand(Player *p, int idx) {
    Card c = p->cards[idx];
    for (int i = idx; i < p->count - 1; i++) p->cards[i] = p->cards[i + 1];
    p->count--;
    return c;
}

static int canPlay(Card c, Card topCard, CardColor currentColor) {
    if (c.type == CAMBIO_COLORE || c.type == PIU4) return 1;
    if (c.color == currentColor) return 1;
    if (c.type == NUMERO && topCard.type == NUMERO && c.numero == topCard.numero) return 1;
    if (c.type != NUMERO && c.type == topCard.type) return 1;
    return 0;
}

static int nextPlayer(int cur, int n, int dir) {
    return (cur + dir + n) % n;
}

static CardColor chooseColorBot(Player *bot) {
    int cnt[4] = {0};
    for (int i = 0; i < bot->count; i++)
        if (bot->cards[i].color <= VERDE) cnt[bot->cards[i].color]++;
    int best = 0;
    for (int i = 1; i < 4; i++) if (cnt[i] > cnt[best]) best = i;
    return (CardColor)best;
}

// ─── Game initialization ──────────────────────────────────────────────────────
static void startGame(int numPlayers, int vsMode) {
    G.numPlayers  = numPlayers;
    G.direction   = 1;
    G.skipNext    = 0;
    G.drawPenalty = 0;
    G.winner      = -1;
    G.cpuThinking = 0;
    G.cpuDelay    = 0;
    G.message[0]  = '\0';
    G.messageTimer= 0;
    G.hoveredCard = -1;

    for (int i = 0; i < numPlayers; i++) {
        if (vsMode == 1) {
            if (i == 0) { strcpy(players[0].nome, "You");  G.players[0].isCPU = 0; }
            else        { snprintf(G.players[i].nome, 32, "CPU %d", i); G.players[i].isCPU = 1; }
        } else {
            snprintf(G.players[i].nome, 32, "Player %d", i + 1);
            G.players[i].isCPU = 0;
        }
        G.players[i].count = 0;
    }

    initDeck(&G.deck);
    shuffleDeck(&G.deck);

    for (int i = 0; i < 7; i++)
        for (int p = 0; p < numPlayers; p++)
            addToHand(&G.players[p], drawCard(&G.deck));

    G.topCard = drawCard(&G.deck);
    while (G.topCard.type == CAMBIO_COLORE || G.topCard.type == PIU4)
        G.topCard = drawCard(&G.deck);

    G.currentColor  = G.topCard.color;
    G.currentPlayer = 0;
    G.screen        = SCREEN_GAME;
}

// ─── Apply card effects ───────────────────────────────────────────────────────
static void applyCardEffect(Card played, int playerIdx) {
    Player *p = &G.players[playerIdx];

    if (played.type != CAMBIO_COLORE && played.type != PIU4)
        G.currentColor = played.color;

    if (played.type == CAMBIO_COLORE) {
        if (p->isCPU) {
            G.currentColor = chooseColorBot(p);
            snprintf(G.message, sizeof(G.message), "%s chose %s", p->nome, colorName(G.currentColor));
            G.messageTimer = 2.0f;
        } else {
            G.screen = SCREEN_COLOR_PICK;
            G.colorPickFor = playerIdx;
            return;
        }
    } else if (played.type == PIU4) {
        if (p->isCPU) {
            G.currentColor = chooseColorBot(p);
            snprintf(G.message, sizeof(G.message), "%s chose %s", p->nome, colorName(G.currentColor));
            G.messageTimer = 2.0f;
        } else {
            G.screen = SCREEN_COLOR_PICK;
            G.colorPickFor = playerIdx;
            return;
        }
        G.drawPenalty = 4;
    } else if (played.type == PIU2) {
        G.drawPenalty = 2;
    } else if (played.type == SALTA) {
        G.skipNext = 1;
    } else if (played.type == INVERTI) {
        if (G.numPlayers == 2) {
            G.skipNext = 1;
        } else {
            G.direction = -G.direction;
            snprintf(G.message, sizeof(G.message), "Direction reversed!");
            G.messageTimer = 1.5f;
        }
    }

    // advance turn
    G.currentPlayer = nextPlayer(G.currentPlayer, G.numPlayers, G.direction);
}

// ─── CPU turn ─────────────────────────────────────────────────────────────────
static void doCpuTurn(void) {
    Player *p = &G.players[G.currentPlayer];

    // handle drawPenalty
    if (G.drawPenalty > 0) {
        for (int i = 0; i < G.drawPenalty; i++)
            if (!deckEmpty(&G.deck)) addToHand(p, drawCard(&G.deck));
        snprintf(G.message, sizeof(G.message), "%s drew %d cards!", p->nome, G.drawPenalty);
        G.messageTimer = 1.5f;
        G.drawPenalty  = 0;
        G.currentPlayer = nextPlayer(G.currentPlayer, G.numPlayers, G.direction);
        return;
    }

    if (G.skipNext) {
        snprintf(G.message, sizeof(G.message), "%s skipped!", p->nome);
        G.messageTimer = 1.5f;
        G.skipNext = 0;
        G.currentPlayer = nextPlayer(G.currentPlayer, G.numPlayers, G.direction);
        return;
    }

    // find playable card
    int idx = -1;
    for (int i = 0; i < p->count; i++) {
        if (canPlay(p->cards[i], G.topCard, G.currentColor)) { idx = i; break; }
    }

    if (idx == -1) {
        if (!deckEmpty(&G.deck)) {
            addToHand(p, drawCard(&G.deck));
            Card last = p->cards[p->count - 1];
            if (canPlay(last, G.topCard, G.currentColor)) {
                G.topCard = removeFromHand(p, p->count - 1);
                snprintf(G.message, sizeof(G.message), "%s drew & played!", p->nome);
                G.messageTimer = 1.5f;
                applyCardEffect(G.topCard, G.currentPlayer);
                return;
            }
        }
        snprintf(G.message, sizeof(G.message), "%s drew a card.", p->nome);
        G.messageTimer = 1.5f;
        G.currentPlayer = nextPlayer(G.currentPlayer, G.numPlayers, G.direction);
    } else {
        G.topCard = removeFromHand(p, idx);
        snprintf(G.message, sizeof(G.message), "%s played %s %s", p->nome,
                 colorName(G.topCard.color), cardLabel(G.topCard));
        G.messageTimer = 1.5f;
        applyCardEffect(G.topCard, G.currentPlayer);
    }
}

// ─── Draw card helper ─────────────────────────────────────────────────────────
static void DrawCard2D(Card c, int x, int y, int w, int h, int highlighted, CardColor overrideColor) {
    Color base  = rayColor(c.color);
    Color inner = (Color){255,255,255,230};
    Color text  = (c.color == GIALLO) ? BLACK : WHITE;

    // for wilds shown with an override color highlight
    if ((c.type == CAMBIO_COLORE || c.type == PIU4) && overrideColor != NERO) {
        base = rayColor(overrideColor);
    }

    // shadow
    DrawRectangleRounded((Rectangle){x+3, y+3, w, h}, 0.15f, 8, (Color){0,0,0,80});
    // card body
    DrawRectangleRounded((Rectangle){x, y, w, h}, 0.15f, 8, base);
    // inner oval
    DrawEllipse(x + w/2, y + h/2, w * 0.32f, h * 0.42f, inner);
    // highlight border
    if (highlighted) {
        DrawRectangleRoundedLines((Rectangle){x-2, y-2, w+4, h+4}, 0.15f, 8, 3.0f, YELLOW);
    }

    // label
    const char *lbl = cardLabel(c);
    int fs = (strlen(lbl) <= 2) ? 22 : 16;
    int tw = MeasureText(lbl, fs);
    DrawText(lbl, x + w/2 - tw/2, y + h/2 - fs/2, fs, (c.color == GIALLO) ? BLACK : DARKGRAY);
}

static void DrawCardBack(int x, int y, int w, int h) {
    DrawRectangleRounded((Rectangle){x+3,y+3,w,h}, 0.15f, 8, (Color){0,0,0,80});
    DrawRectangleRounded((Rectangle){x,y,w,h}, 0.15f, 8, (Color){20,20,120,255});
    DrawEllipse(x+w/2, y+h/2, w*0.32f, h*0.42f, (Color){200,50,50,255});
    int tw = MeasureText("UNO", 16);
    DrawText("UNO", x+w/2-tw/2, y+h/2-8, 16, WHITE);
}

// ─── Main draw functions ───────────────────────────────────────────────────────

static void DrawMenu(void) {
    ClearBackground((Color){15,15,35,255});

    // Title
    const char *title = "UNO";
    int ts = 120;
    int tw = MeasureText(title, ts);
    // Shadow
    DrawText(title, SCREEN_W/2 - tw/2 + 5, 100 + 5, ts, (Color){0,0,0,100});
    // Colored letters
    DrawText("U", SCREEN_W/2 - tw/2,       100, ts, (Color){220,40,40,255});
    DrawText("N", SCREEN_W/2 - tw/2 + tw/3, 100, ts, (Color){240,200,30,255});
    DrawText("O", SCREEN_W/2 - tw/2 + tw*2/3, 100, ts, (Color){30,170,70,255});

    DrawText("Card Game", SCREEN_W/2 - MeasureText("Card Game",28)/2, 230, 28, (Color){180,180,180,255});

    // Buttons
    Rectangle b1 = {SCREEN_W/2 - 160, 310, 320, 60};
    Rectangle b2 = {SCREEN_W/2 - 160, 390, 320, 60};

    Vector2 mouse = GetMousePosition();
    int h1 = CheckCollisionPointRec(mouse, b1);
    int h2 = CheckCollisionPointRec(mouse, b2);

    DrawRectangleRounded(b1, 0.3f, 8, h1 ? (Color){220,40,40,255} : (Color){140,20,20,255});
    DrawRectangleRounded(b2, 0.3f, 8, h2 ? (Color){30,170,70,255} : (Color){15,100,40,255});

    const char *l1 = "vs CPU";
    const char *l2 = "Multiplayer (2-4 Players)";
    DrawText(l1, SCREEN_W/2 - MeasureText(l1,24)/2, 327, 24, WHITE);
    DrawText(l2, SCREEN_W/2 - MeasureText(l2,20)/2, 410, 20, WHITE);

    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        if (h1) { G.screen = SCREEN_SETUP; G.setupMode = 1; G.setupPlayerCount = 2; }
        if (h2) { G.screen = SCREEN_SETUP; G.setupMode = 2; G.setupPlayerCount = 2; }
    }
}

static void DrawSetup(void) {
    ClearBackground((Color){15,15,35,255});

    const char *title = G.setupMode == 1 ? "vs CPU Setup" : "Multiplayer Setup";
    DrawText(title, SCREEN_W/2 - MeasureText(title,40)/2, 80, 40, WHITE);

    if (G.setupMode == 2) {
        DrawText("Number of players:", SCREEN_W/2 - MeasureText("Number of players:", 28)/2, 200, 28, (Color){200,200,200,255});

        for (int n = 2; n <= 4; n++) {
            Rectangle r = {SCREEN_W/2 - 50 + (n-3)*130, 260, 100, 60};
            Vector2 m   = GetMousePosition();
            int hov     = CheckCollisionPointRec(m, r);
            int sel     = (G.setupPlayerCount == n);
            Color bg    = sel ? (Color){30,170,70,255} : (hov ? (Color){60,60,100,255} : (Color){30,30,60,255});
            DrawRectangleRounded(r, 0.3f, 8, bg);
            char buf[4]; snprintf(buf, 4, "%d", n);
            DrawText(buf, r.x + 50 - MeasureText(buf,28)/2, r.y+16, 28, WHITE);
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && hov) G.setupPlayerCount = n;
        }
    } else {
        DrawText("You vs CPU", SCREEN_W/2 - MeasureText("You vs CPU",32)/2, 260, 32, (Color){240,200,30,255});
    }

    Rectangle go = {SCREEN_W/2 - 140, 400, 280, 64};
    Vector2 m = GetMousePosition();
    int hg = CheckCollisionPointRec(m, go);
    DrawRectangleRounded(go, 0.3f, 8, hg ? (Color){220,40,40,255} : (Color){140,20,20,255});
    const char *gl = "Start Game!";
    DrawText(gl, go.x + 140 - MeasureText(gl,26)/2, go.y+19, 26, WHITE);

    Rectangle back = {40, 40, 120, 44};
    int hb = CheckCollisionPointRec(m, back);
    DrawRectangleRounded(back, 0.3f, 8, hb ? (Color){80,80,80,255} : (Color){40,40,40,255});
    DrawText("< Back", back.x+10, back.y+12, 22, WHITE);

    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        if (hg) startGame(G.setupPlayerCount, G.setupMode);
        if (hb) G.screen = SCREEN_MENU;
    }
}

static void DrawColorPick(void) {
    // darken
    DrawRectangle(0, 0, SCREEN_W, SCREEN_H, (Color){0,0,0,160});

    DrawRectangleRounded((Rectangle){SCREEN_W/2-220, SCREEN_H/2-150, 440, 300}, 0.1f, 8, (Color){30,30,50,255});
    const char *msg = "Choose a color:";
    DrawText(msg, SCREEN_W/2 - MeasureText(msg,28)/2, SCREEN_H/2 - 120, 28, WHITE);

    CardColor cols[4] = {BLU, GIALLO, ROSSO, VERDE};
    const char *names[4] = {"Blue","Yellow","Red","Green"};
    Vector2 mouse = GetMousePosition();

    for (int i = 0; i < 4; i++) {
        int x = SCREEN_W/2 - 190 + i * 100;
        int y = SCREEN_H/2 - 50;
        Rectangle r = {x, y, 80, 80};
        int hov = CheckCollisionPointRec(mouse, r);
        DrawRectangleRounded(r, 0.2f, 8, rayColor(cols[i]));
        if (hov) DrawRectangleRoundedLines(r, 0.2f, 8, 3, WHITE);
        int tw = MeasureText(names[i], 16);
        DrawText(names[i], x + 40 - tw/2, y + 88, 16, WHITE);

        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && hov) {
            G.currentColor = cols[i];
            snprintf(G.message, sizeof(G.message), "Color: %s", names[i]);
            G.messageTimer = 1.5f;
            if (G.topCard.type == PIU4) G.drawPenalty = 4;
            G.currentPlayer = nextPlayer(G.colorPickFor, G.numPlayers, G.direction);
            G.screen = SCREEN_GAME;
        }
    }
}

static void DrawWin(void) {
    ClearBackground((Color){10,10,25,255});

    const char *wl = "Winner!";
    DrawText(wl, SCREEN_W/2 - MeasureText(wl,80)/2, 140, 80, (Color){240,200,30,255});

    char buf[64];
    snprintf(buf, sizeof(buf), "%s wins!", G.players[G.winner].nome);
    DrawText(buf, SCREEN_W/2 - MeasureText(buf,44)/2, 260, 44, WHITE);

    Rectangle r = {SCREEN_W/2 - 150, 380, 300, 60};
    Vector2 m = GetMousePosition();
    int h = CheckCollisionPointRec(m, r);
    DrawRectangleRounded(r, 0.3f, 8, h ? (Color){30,170,70,255} : (Color){15,100,40,255});
    const char *pl = "Play Again";
    DrawText(pl, r.x + 150 - MeasureText(pl,26)/2, r.y+17, 26, WHITE);

    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && h) G.screen = SCREEN_MENU;
}

// ─── Main game screen ─────────────────────────────────────────────────────────
static void DrawGame(void) {
    // Background
    ClearBackground((Color){20,60,30,255});

    // Table felt
    DrawEllipse(SCREEN_W/2, SCREEN_H/2, 380, 240, (Color){15,90,40,255});

    Player *cur = &G.players[G.currentPlayer];
    Vector2 mouse = GetMousePosition();

    // ── Top card ──────────────────────────────────────────────────────────────
    int tcx = SCREEN_W/2 - CARD_W/2 + 30;
    int tcy = SCREEN_H/2 - CARD_H/2;
    DrawCard2D(G.topCard, tcx, tcy, CARD_W, CARD_H, 0, G.currentColor);
    // Current color indicator
    DrawCircle(tcx - 50, tcy + CARD_H/2, 18, rayColor(G.currentColor));
    DrawCircleLines(tcx - 50, tcy + CARD_H/2, 18, WHITE);
    const char *cn = colorName(G.currentColor);
    DrawText(cn, tcx - 50 - MeasureText(cn,12)/2, tcy + CARD_H/2 + 22, 12, WHITE);

    // ── Deck pile ─────────────────────────────────────────────────────────────
    int deckX = SCREEN_W/2 - CARD_W - 20;
    int deckY = SCREEN_H/2 - CARD_H/2;
    DrawCardBack(deckX, deckY, CARD_W, CARD_H);

    // Deck click (draw) only for human player when it's their turn
    if (!cur->isCPU && G.screen == SCREEN_GAME) {
        Rectangle deckRect = {deckX, deckY, CARD_W, CARD_H};
        if (CheckCollisionPointRec(mouse, deckRect)) {
            DrawRectangleRoundedLines(deckRect, 0.15f, 8, 3, (Color){255,255,100,200});
            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                if (!deckEmpty(&G.deck)) {
                    addToHand(cur, drawCard(&G.deck));
                    snprintf(G.message, sizeof(G.message), "You drew a card.");
                    G.messageTimer = 1.2f;
                    // check if just-drawn card is playable
                    Card last = cur->cards[cur->count - 1];
                    if (canPlay(last, G.topCard, G.currentColor)) {
                        snprintf(G.message, sizeof(G.message), "Drew card is playable — click it!");
                        G.messageTimer = 2.0f;
                    } else {
                        G.currentPlayer = nextPlayer(G.currentPlayer, G.numPlayers, G.direction);
                    }
                }
            }
        }
    }

    // ── Draw all player hands ──────────────────────────────────────────────────
    for (int pi = 0; pi < G.numPlayers; pi++) {
        Player *p = &G.players[pi];

        // positions: 0=bottom, 1=top, 2=left, 3=right (up to 4)
        if (pi == 0) {
            // Human hand — bottom
            int total = p->count;
            int startX = SCREEN_W/2 - (total * 44) / 2;
            int y = SCREEN_H - CARD_H - 20;

            for (int i = 0; i < total; i++) {
                int x   = startX + i * 44;
                int hov = 0;
                int playable = canPlay(p->cards[i], G.topCard, G.currentColor);

                if (G.currentPlayer == 0 && !p->isCPU && G.screen == SCREEN_GAME) {
                    Rectangle r = {x, y - 10, CARD_W, CARD_H + 10};
                    if (CheckCollisionPointRec(mouse, r)) {
                        hov = 1;
                        G.hoveredCard = i;
                        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && playable) {
                            G.topCard = removeFromHand(p, i);
                            applyCardEffect(G.topCard, 0);
                            // Check win
                            if (p->count == 0) { G.winner = 0; G.screen = SCREEN_WIN; }
                            break;
                        }
                    }
                }
                int drawY = hov ? y - 18 : y;
                DrawCard2D(p->cards[i], x, drawY, CARD_W, CARD_H, hov && playable, NERO);
                if (G.currentPlayer == 0 && !playable && !p->isCPU) {
                    DrawRectangleRounded((Rectangle){x, drawY, CARD_W, CARD_H}, 0.15f, 8, (Color){0,0,0,100});
                }
            }

            // Player label
            Color labelColor = (G.currentPlayer == pi) ? (Color){240,200,30,255} : WHITE;
            snprintf(G.players[pi].nome, 32, "You (%d cards)", p->count);
            int lw = MeasureText(G.players[pi].nome, 18);
            DrawText(G.players[pi].nome, SCREEN_W/2 - lw/2, SCREEN_H - CARD_H - 50, 18, labelColor);
            // UNO warning
            if (p->count == 1) {
                DrawText("UNO!", SCREEN_W/2 - MeasureText("UNO!",28)/2, SCREEN_H - CARD_H - 82, 28, (Color){220,40,40,255});
            }

        } else if (pi == 1) {
            // CPU / Player 2 — top
            int total = p->count;
            int startX = SCREEN_W/2 - (total * 30) / 2;
            int y = 10;
            for (int i = 0; i < total; i++) {
                DrawCardBack(startX + i * 30, y, 50, 76);
            }
            Color labelColor = (G.currentPlayer == pi) ? (Color){240,200,30,255} : WHITE;
            char lbl[64]; snprintf(lbl, 64, "%s (%d cards)", p->nome, p->count);
            DrawText(lbl, SCREEN_W/2 - MeasureText(lbl,16)/2, y + 82, 16, labelColor);
            if (p->count == 1) DrawText("UNO!", SCREEN_W/2 - MeasureText("UNO!",22)/2, y + 102, 22, (Color){220,40,40,255});

        } else if (pi == 2) {
            // Player 3 — left
            int total = p->count;
            int startY = SCREEN_H/2 - (total * 22) / 2;
            for (int i = 0; i < total; i++) DrawCardBack(8, startY + i * 22, 50, 76);
            Color labelColor = (G.currentPlayer == pi) ? (Color){240,200,30,255} : WHITE;
            char lbl[64]; snprintf(lbl, 64, "%s\n(%d)", p->nome, p->count);
            DrawText(lbl, 8, SCREEN_H/2 - 10, 14, labelColor);

        } else if (pi == 3) {
            // Player 4 — right
            int total = p->count;
            int startY = SCREEN_H/2 - (total * 22) / 2;
            for (int i = 0; i < total; i++) DrawCardBack(SCREEN_W - 58, startY + i * 22, 50, 76);
            Color labelColor = (G.currentPlayer == pi) ? (Color){240,200,30,255} : WHITE;
            char lbl[64]; snprintf(lbl, 64, "%s\n(%d)", p->nome, p->count);
            DrawText(lbl, SCREEN_W - 58, SCREEN_H/2 - 10, 14, labelColor);
        }
    }

    // ── Direction indicator ───────────────────────────────────────────────────
    const char *dir = G.direction == 1 ? "►" : "◄";
    DrawText(dir, SCREEN_W - 60, SCREEN_H/2 - 10, 28, (Color){255,255,255,150});

    // ── Message banner ────────────────────────────────────────────────────────
    if (G.messageTimer > 0) {
        int alpha = (int)(G.messageTimer > 0.5f ? 255 : G.messageTimer * 510);
        int mw = MeasureText(G.message, 22);
        DrawRectangleRounded((Rectangle){SCREEN_W/2 - mw/2 - 16, SCREEN_H/2 - 60, mw + 32, 40}, 0.4f, 8, (Color){0,0,0,(unsigned char)alpha});
        DrawText(G.message, SCREEN_W/2 - mw/2, SCREEN_H/2 - 52, 22, (Color){255,255,255,(unsigned char)alpha});
    }

    // ── CPU thinking indicator ────────────────────────────────────────────────
    if (G.cpuThinking) {
        int dots = ((int)(GetTime() * 3)) % 4;
        char buf[16] = "Thinking";
        for (int i = 0; i < dots; i++) strcat(buf, ".");
        DrawText(buf, SCREEN_W/2 - MeasureText(buf,22)/2, SCREEN_H/2 + 20, 22, (Color){200,200,200,200});
    }

    // ── Instruction hint ──────────────────────────────────────────────────────
    if (G.currentPlayer == 0 && !cur->isCPU) {
        DrawText("Click a card to play | Click deck to draw", 20, SCREEN_H - 24, 16, (Color){180,180,180,180});
    }

    // Menu button
    Rectangle menuBtn = {20, 20, 100, 36};
    int mh = CheckCollisionPointRec(mouse, menuBtn);
    DrawRectangleRounded(menuBtn, 0.3f, 8, mh ? (Color){80,80,80,255} : (Color){30,30,30,200});
    DrawText("Menu", 44, 28, 18, WHITE);
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && mh) G.screen = SCREEN_MENU;
}

// ─── CPU turn advancement (with delay) ───────────────────────────────────────
static void UpdateGame(float dt) {
    if (G.screen != SCREEN_GAME) return;

    if (G.messageTimer > 0) G.messageTimer -= dt;

    Player *cur = &G.players[G.currentPlayer];

    // Check win after any move
    for (int i = 0; i < G.numPlayers; i++) {
        if (G.players[i].count == 0) {
            G.winner = i;
            G.screen = SCREEN_WIN;
            return;
        }
    }

    // Check deck empty
    if (deckEmpty(&G.deck)) {
        // find player with fewest cards
        int best = 0;
        for (int i = 1; i < G.numPlayers; i++)
            if (G.players[i].count < G.players[best].count) best = i;
        G.winner = best;
        G.screen = SCREEN_WIN;
        return;
    }

    if (cur->isCPU) {
        if (!G.cpuThinking) {
            G.cpuThinking = 1;
            G.cpuDelay    = 1.2f;
        } else {
            G.cpuDelay -= dt;
            if (G.cpuDelay <= 0) {
                G.cpuThinking = 0;
                doCpuTurn();
            }
        }
    }
}

// ─── Entry point ──────────────────────────────────────────────────────────────
int main(void) {
    srand((unsigned int)time(NULL));

    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE);
    InitWindow(SCREEN_W, SCREEN_H, "UNO - Card Game");
    SetTargetFPS(60);

    G.screen           = SCREEN_MENU;
    G.setupMode        = 1;
    G.setupPlayerCount = 2;
    G.winner           = -1;

    while (!WindowShouldClose()) {
        float dt = GetFrameTime();
        UpdateGame(dt);

        BeginDrawing();
        switch (G.screen) {
            case SCREEN_MENU:       DrawMenu();       break;
            case SCREEN_SETUP:      DrawSetup();      break;
            case SCREEN_GAME:
                DrawGame();
                break;
            case SCREEN_COLOR_PICK:
                DrawGame();
                DrawColorPick();
                break;
            case SCREEN_WIN:        DrawWin();        break;
        }
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
